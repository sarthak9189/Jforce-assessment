package com.lithan.WebApp.service;

import com.lithan.WebApp.dto.User;

public interface MyUserService {

	public String addUser(User us);
	public String updateUser(User us);
	
}
