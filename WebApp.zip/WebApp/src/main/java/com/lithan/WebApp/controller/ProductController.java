package com.lithan.WebApp.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import com.lithan.WebApp.service.MyUserService;
import com.lithan.WebApp.dto.User;

@Controller
public class ProductController {
	

	
	@Autowired
	MyUserService myservice;
	
	@GetMapping(value="/")
	public String myHomepage() {
		
		return "home";
		
	}
	
	@GetMapping(value = "/register")
	public String myRegisterPage(@ModelAttribute("sarthak") User us) {
		//System.out.println("hiii");
		
		return "registration";
		
	}
	@PostMapping(value = "/myreg")
	public String addRegisterPage(@ModelAttribute("sarthak") User us) {
		myservice.addUser(us);
		return "redirect:/login";
		
	}
	
	@GetMapping(value = "/user")
	public String myuserPage() {
		return "userpage";
		
	}
	@GetMapping(value = "/admin")
	public String myadminPage() {
		return "adminpage";
		
	}
	
	
}
