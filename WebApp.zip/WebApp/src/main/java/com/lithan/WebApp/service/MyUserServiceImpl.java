package com.lithan.WebApp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.lithan.WebApp.dao.UserRepository;
import com.lithan.WebApp.dto.User;
@Service
public class MyUserServiceImpl implements MyUserService {
	private PasswordEncoder passwordencoder;
	@Autowired
	UserRepository userrepo;
	@Autowired
	public MyUserServiceImpl(PasswordEncoder encoder) {
		// TODO Auto-generated constructor stub
		this.passwordencoder=encoder;
	}
	@Override
	public String addUser(User us) {
		// TODO Auto-generated method stub
		us.setRole("USER");
		us.setPassword(passwordencoder.encode(us.getPassword()));
		 userrepo.save(us);
		 return "DATA ADDED";
	}

	@Override
	public String updateUser(User us) {
		// TODO Auto-generated method stub
		return null;
	}

}
