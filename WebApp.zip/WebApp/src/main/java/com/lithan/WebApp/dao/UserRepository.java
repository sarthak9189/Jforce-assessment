package com.lithan.WebApp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.lithan.WebApp.dto.User;

public interface UserRepository extends JpaRepository<User, Long> {

	User findByUserName(String name);
}
